package br.uff.ic.tpa.smartpet;
import br.uff.ic.tpa.smartpet.form.*;

/**
 *
 * @author leonardo
 */
public class Main {
    public static void main(String[] args){
        FramePrincipal principal = new FramePrincipal();
        principal.setFocusableWindowState(true);
        principal.setVisible(true);
        
//        while(true)
//            System.out.println("teste");
        
    }
}
